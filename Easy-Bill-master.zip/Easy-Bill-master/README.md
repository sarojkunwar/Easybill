# Easy Bill
'Easy Bill' is the Departmental Store Billing System. This the the Second Semester Project.  
**Tools Used:**  
* C++  
    
